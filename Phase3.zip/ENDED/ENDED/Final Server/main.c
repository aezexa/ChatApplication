#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <winsock2.h>
#include <windows.h>
#include <dirent.h>
#include <time.h>
#define MAX 10000
#define PORT 12345
#define SA struct sockaddr

int server_socket, client_socket;
struct sockaddr_in server, client;
char buffer[5000];

struct user {
    char name[MAX];
    char pass[MAX];
    char authToken[33];
    int in_any_channel;
} userNumber [100];

struct channel {
    char channel_name[MAX];
    char member_name[100][MAX];
    int people_inside;
} channelNumber [100];

void delchar(char *string, int number, int pos)
{
    if ((number + pos - 1) <= strlen(string))
    {
        strcpy(&string[pos - 1], &string[number + pos - 1]);
    }
    return;
}

void socketStuff(){

    int len = sizeof(client);
    client_socket = accept(server_socket, (SA *)&client, &len);
    if (client_socket < 0)
        exit(0);
    return;
}

int channelIntroduction ( void ) {
    int channelCounter = 0;
    char channelTempName[MAX];
    DIR *dir;
    struct dirent *ent;
    if ((dir = opendir ("./Resources/Channels/")) != NULL) {
        /* print all the files and directories within directory */
        ent = readdir (dir); ent = readdir (dir);
        while ((ent = readdir (dir)) != NULL) {
            channelCounter++;
            strcpy(channelTempName, ent->d_name);
            channelTempName[ strlen( channelTempName ) - 13 ] = '\0'; // 13 is size of ".channel.json"
            strcpy (channelNumber [channelCounter - 1] . channel_name, channelTempName) ;
            channelNumber [channelCounter - 1] . people_inside = 0;
            printf ("Channel %s Created.\n", channelTempName);
        }
        closedir (dir);
    } else {
        /* could not open directory */
        perror ("");
    }
    return channelCounter;
}

int userIntroduction ( void ) {
    int userCounter = 0;
    char userTempName[MAX];
    DIR *dir;
    struct dirent *ent;
    if ((dir = opendir ("./Resources/Users/")) != NULL) {
        /* print all the files and directories within directory */
        ent = readdir (dir); ent = readdir (dir);
        while ((ent = readdir (dir)) != NULL) {
            userCounter++;
            strcpy(userTempName, ent->d_name);
            userTempName[ strlen( userTempName ) - 10 ] = '\0'; // 13 is size of ".user.json"
            strcpy ( userNumber [ userCounter - 1 ] . name , userTempName );
            printf ("User %s Registered.\n", userTempName);
        }
        closedir (dir);
    } else {
        /* could not open directory */
        perror ("");
    }
    return userCounter;
}

void chat()
{
    char username[MAX];
    char password[MAX];
    char channel_name[MAX];
    char auth_token_temp[33];
    char message[5000];
    int n;
    srand(time(NULL));
    puts("***************************************** CHANNELS *********************************************");
    // List of channels ------------------------------------------------------------------------------------------------
    int channelCounter = channelIntroduction(); //REMEMBER TO CORRECT ARRAYS
    puts("****************************************** USERS **********************************************");
    // List of users ---------------------------------------------------------------------------------------------------
    int userCounter = userIntroduction(); //REMEMBER TO CORRECT ARRAYS
    puts("**************************************** COUNTERS *********************************************");

    printf("User Counter : %d\n"
           "Channel Counter : %d\n"
            ,userCounter,channelCounter);

    // The Program -----------------------------------------------------------------------------------------------------
    while ( true ) {
        memset ( buffer , 0 , sizeof ( buffer ));

        socketStuff ( );
        recv ( client_socket , buffer , sizeof ( buffer ) , 0 );

        // ---------------------------------------------- REGISTER -----------------------------------------------------

        if ( strncmp ( "register" , buffer , 8 ) == 0 ) {
            // Making username and password variables ------------------------------------------------------------------

            delchar ( buffer , 9 , 0 );
            memset(username,0, MAX);
            memset(password,0, MAX);
            sscanf ( buffer , "%s %s" , username , password );
            username[ strlen ( username ) - 1 ] = '\0';

            // Searching for the file ----------------------------------------------------------------------------------

            char addressAndNameOfFile[1000];
            CreateDirectory ( "./Resources" , NULL);
            CreateDirectory ( "./Resources/Users" , NULL);
            sprintf ( addressAndNameOfFile , "./Resources/Users/%s.user.json" , username );
            FILE * filePointer = NULL;
            filePointer = fopen ( addressAndNameOfFile , "r" );

            // Error for when the user existed -------------------------------------------------------------------------

            if ( filePointer != NULL) {
                char messageForClientString[MAX] = "{\n"
                                                "        \"type\": \"Error\",\n"
                                                "        \"content\":      \"this username is not available.\"\n"
                                                "}";
                send (client_socket , messageForClientString , 10000 , 0 );
                printf("%s\n", messageForClientString);
                fclose ( filePointer );
            } else {

                fclose ( filePointer );

                // Writing down username and password in a json file ---------------------------------------------------

                char userAndPassString[1000];
                sprintf(userAndPassString, "{\n"
                                         "        \"username\": \"%s\",\n"
                                         "        \"password\":      \"%s\"\n"
                                         "}", username, password);
                filePointer = fopen ( addressAndNameOfFile , "w" );
                fprintf ( filePointer , "%s", userAndPassString );
                fclose ( filePointer );

                // Sending a success message to client -----------------------------------------------------------------

                char messageForClientString[MAX];
                sprintf(messageForClientString, "{\n"
                                           "        \"type\": \"Successful\",\n"
                                           "        \"content\":      \"\"\n"
                                           "}");
                send ( client_socket , messageForClientString , 10000 , 0 );
                printf("%s\n", messageForClientString);

            }
        }

        // ----------------------------------------------- LOGIN -------------------------------------------------------

        else if (strncmp("login", buffer, 5) == 0) {
            // Making username and password variables ------------------------------------------------------------------
            delchar(buffer, 6, 0);
            memset(username,0, MAX);
            memset(password,0, MAX);
            sscanf(buffer, "%s %s", username, password);
            username[strlen(username) - 1] = '\0';

            // Searching for the file ----------------------------------------------------------------------------------

            char addressAndNameOfFile[1000];
            sprintf(addressAndNameOfFile, "./Resources/Users/%s.user.json", username); //MISTAKE : It is not case sensitive
            FILE *filePointer = NULL;
            filePointer = fopen(addressAndNameOfFile, "r");

            // Error for when the user didn't exist --------------------------------------------------------------------

            if (filePointer == NULL ) {

                char messageForClientString[MAX] = "{\n"
                                               "        \"type\": \"Error\",\n"
                                               "        \"content\":      \"Username is not valid.\"\n"
                                               "}";
                send(client_socket, messageForClientString, 10000, 0);
                printf("%s\n", messageForClientString);
                // fclose is after "else"

            } else {

                // Checking the password -------------------------------------------------------------------------------

                char contentString[MAX];
//                fread(contentString, sizeof(char) , 10000, filePointer);
                fscanf(filePointer, "%[^\0]", contentString);
                // fclose is after "else"

                // If the password was incorrect -----------------------------------------------------------------------

                char type[MAX];
                char content[MAX];

                sscanf(contentString, "%*s%*s%s%*s%s%*s", type, content);
                type [ strlen(type) - 2 ] = '\0';
                strcpy (type, type+1);
                content [ strlen(content) - 1 ] = '\0';
                strcpy (content, content+1);

                if (strcmp (password, content) != 0) {

                    char messageForClientString[MAX] = "{\n"
                                                   "        \"type\": \"Error\",\n"
                                                   "        \"content\":      \"Wrong password.\"\n"
                                                   "}";
                    send(client_socket, messageForClientString, 10000, 0);
                    printf("%s\n", messageForClientString);

                } else {

                    // If the password was correct: --------------------------------------------------------------------

                    // If the user was already logged in ---------------------------------------------------------------

                    int LoggedError = 0;

                    for (int i = 0; i < userCounter; ++i) {
                        if (strcmp(userNumber[i].name, username) == 0)
                            if (userNumber[i].in_any_channel == 1)
                                LoggedError = 1;
                    }

                    if (LoggedError == 1) {
                        char errorMessage[MAX];
                        sprintf(errorMessage, "The user %s is already logged in.", username);
                        char messageForClientString[MAX];
                        sprintf(messageForClientString, "{\n"
                                                       "        \"type\": \"Error\",\n"
                                                       "        \"content\":      \"%s\"\n"
                                                       "}", errorMessage);
                        send(client_socket, messageForClientString, 10000, 0);
                        printf("%s\n", messageForClientString);

                    } else {

                        // If everything was ok ------------------------------------------------------------------------

                        userCounter++;
                        strcpy(userNumber[userCounter - 1].name, username);
                        strcpy(userNumber[userCounter - 1].pass, password);
                        userNumber[userCounter - 1].in_any_channel = 0;

                        // Making AuthToken and checking if it is unique -----------------------------------------------

                        char authTokenStuff[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz123456789";
                        int authTokenStuffSize = 61;
                        char authToken[33];

                        while (true) {
                            for (int i = 0; i < 32; ++i) {
                                authToken[i] = authTokenStuff[rand() % (authTokenStuffSize)];
                            }
                            authToken[32] = '\0';

                            int freq = 0;

                            for (int i = 0; i < userCounter; i++) {
                                if (strncmp(userNumber[i].authToken, authToken, 32) == 0)
                                    freq++;
                            }
//                            printf("freq is %d\n", freq);
                            if (freq <= 1) {
                                strncpy(userNumber[userCounter - 1].authToken, authToken, 32);
                                break;
                            }
                        }

                        // Sending a success message to client ---------------------------------------------------------


                        char messageForClientString[MAX];
                        sprintf(messageForClientString, "{\n"
                                                        "        \"type\": \"AuthToken\",\n"
                                                        "        \"content\":      \"%s\"\n"
                                                        "}", authToken);
                        send(client_socket, messageForClientString, 10000, 0);
                        printf("%s\n", messageForClientString);

                    }
                }
            }

            fclose(filePointer);

        }

        // ------------------------------------------- CREATE CHANNEL --------------------------------------------------

        else if (strncmp("create channel", buffer, 14) == 0){

            // Extraction ----------------------------------------------------------------------------------------------

            delchar(buffer, 15, 0);
            memset(channel_name,0, MAX);
            sscanf(buffer, "%s %s", channel_name, auth_token_temp);
            channel_name[ strlen ( channel_name ) - 1 ] = '\0';

            // Checking if authToken is acceptable ---------------------------------------------------------------------

            int acceptable = 0;
            int their_user_number = 0;

            for (int i = 0; i < userCounter; ++i) {
                if (strncmp(userNumber[i].authToken, auth_token_temp, 32) == 0) {
                    acceptable = 1;
                    their_user_number = i;
                    }
            }

            if (acceptable == 0) {

                char messageForClientString[MAX] = "{\n"
                                               "        \"type\": \"Error\",\n"
                                               "        \"content\":      \"Unacceptable AuthToken.\"\n"
                                               "}";
                send(client_socket, messageForClientString, 10000, 0);
                printf("%s\n", messageForClientString);

            } else {

                // Checking if channel didn't exist previously ---------------------------------------------------------

                char addressAndNameOfFile[1000];
                CreateDirectory ( "./Resources" , NULL);
                CreateDirectory ( "./Resources/Channels" , NULL);
                sprintf ( addressAndNameOfFile , "./Resources/Channels/%s.channel.json" , channel_name );
                FILE * filePointer = NULL;
                filePointer = fopen(addressAndNameOfFile , "r");
                if (filePointer != NULL) {
                    char messageForClientString[MAX] = "{\n"
                                                   "        \"type\": \"Error\",\n"
                                                   "        \"content\":      \"Channel Exists.\"\n"
                                                   "}";
                    send(client_socket, messageForClientString, 10000, 0);
                    printf("%s\n", messageForClientString);
                    fclose(filePointer);

                } else {
                    fclose(filePointer);

                    // Everything is ok now and we will write information in json --------------------------------------

                    userNumber[their_user_number].in_any_channel = 1;

                    channelCounter++;
                    channelNumber[channelCounter - 1].people_inside = 1;
                    strcpy(channelNumber[channelCounter - 1].channel_name, channel_name);
                    strcpy(channelNumber[channelCounter - 1].member_name[0], userNumber[their_user_number].name);

                    char channelString[MAX];
                    sprintf(channelString, "{\n"
                                           "\t\"messages\":\t[{\n"
                                           "\t\t\t\"sender\":\t\"server\",\n"
                                           "\t\t\t\"content\":\t\"%s created %s\"\n"
                                           "\t\t}],\n"
                                           "\t\"name\":\t\"%s\"\n"
                                           "}", userNumber[their_user_number].name, channel_name, channel_name);

                    filePointer = fopen ( addressAndNameOfFile , "w" );
                    fprintf (filePointer , "%s", channelString );
                    fclose ( filePointer );

                    // Sending a success message to client -------------------------------------------------------------

                    char messageForClientString[MAX] = "{\n"
                                                   "        \"type\": \"Successful\",\n"
                                                   "        \"content\":      \"\"\n"
                                                   "}";
                    send(client_socket, messageForClientString, 10000, 0);
                    printf("%s\n", messageForClientString);
                }
            }

        }

        // -------------------------------------------- JOIN CHANNEL ---------------------------------------------------

        else if (strncmp("join channel", buffer, 12) == 0) {

            // Extraction ----------------------------------------------------------------------------------------------

            delchar(buffer, 13, 0);
            memset(channel_name,0, MAX);
            sscanf(buffer, "%s %s", channel_name, auth_token_temp);
            channel_name[strlen(channel_name) - 1] = '\0';

            // Checking if authToken is acceptable ---------------------------------------------------------------------
            int acceptable = 0;
            int their_user_number = 0;

            for (int i = 0; i < userCounter; ++i) {
                if (strncmp(userNumber[i].authToken, auth_token_temp, 32) == 0) {
                    acceptable = 1;
                    their_user_number = i;
                    break;
                }
            }

            if (acceptable == 0) {

                char messageForClientString[MAX] = "{\n"
                                               "        \"type\": \"Error\",\n"
                                               "        \"content\":      \"Unacceptable AuthToken.\"\n"
                                               "}";
                send(client_socket, messageForClientString, 10000, 0);
                printf("%s\n", messageForClientString);

            } else {

                // Checking if channel exists --------------------------------------------------------------------------

                char addressAndNameOfFile[1000];
                sprintf(addressAndNameOfFile, "./Resources/Channels/%s.channel.json", channel_name);
                FILE *filePointer = NULL;
                filePointer = fopen(addressAndNameOfFile, "r");
                if (filePointer == NULL) {
                    char messageForClientString[MAX] = "{\n"
                                                   "        \"type\": \"Error\",\n"
                                                   "        \"content\":      \"Channel not found.\"\n"
                                                   "}";
                    send(client_socket, messageForClientString, 10000, 0);
                    printf("%s\n", messageForClientString);
                    fclose(filePointer);

                } else {

                    // Adding the user to the channel ------------------------------------------------------------------

                    int their_channel_number = 0;

                    for (int i = 0; i < channelCounter; i++) {
                        if (strcpy ( channelNumber[i].channel_name, channel_name ) == 0) {
                            their_channel_number = i;
                        }
                    }

                    userNumber[their_user_number].in_any_channel = 1;
                    channelNumber[their_channel_number].people_inside++;

                    strcpy(channelNumber[their_channel_number].member_name[channelNumber[their_channel_number].people_inside - 1], userNumber[their_user_number].name);


                    // Everything is ok now we remake the json ---------------------------------------------------------

                    fclose(filePointer);

                    filePointer = fopen (addressAndNameOfFile , "r+");
                    char contentString[MAX];
                    rewind(filePointer);
//                    fread(contentString, sizeof(char) , 10000, filePointer);
                    fscanf(filePointer, "%[^\0]", contentString);
                    printf("OLD JOIN : \n%s\n", contentString);
                    puts("*********************************************************");
                    fseek(filePointer, -19 - strlen(channel_name), SEEK_END);
                    fprintf(filePointer, "}, {\n"
                                         "\t\t\t\"sender\":\t\"server\",\n"
                                         "\t\t\t\"content\":\t\"%s joined the channel.\""
                                         "\n\t\t}],\n"
                                         "\t\"name\":\t\"%s\"\n"
                                         "}", userNumber[their_user_number].name, channel_name);
                    rewind(filePointer);
//                    fread(contentString, sizeof(char) , 10000, filePointer);
                    fscanf(filePointer, "%[^\0]", contentString);
                    printf("NEW JOIN : \n%s\n", contentString);
                    puts("*********************************************************");
                    fclose ( filePointer );

                    // Sending a success message to client -------------------------------------------------------------

                    char messageForClientString[MAX] = "{\n"
                                                   "        \"type\": \"Successful\",\n"
                                                   "        \"content\":      \"\"\n"
                                                   "}";
                    send(client_socket, messageForClientString, 10000, 0);
                    printf("%s\n", messageForClientString);
                }
            }
        }

        // ----------------------------------------------- SEND --------------------------------------------------------

        else if (strncmp("send", buffer, 4) == 0){

            // Extraction ----------------------------------------------------------------------------------------------
            delchar ( buffer , 5 , 0 );
            buffer[ strlen ( buffer ) - 1 ] = '\0';
            char* pos; //position of last char
            pos = buffer + strlen(buffer) - 1; // make pos point to last char of string
            for (int i = 0; i < 32; i++) {
                auth_token_temp[i] = * ( pos - (31 - i));
            }
            memset(message,0, sizeof(message));
            strncpy(message, buffer, strlen(buffer) - 34);

            // Checking if authToken is acceptable ---------------------------------------------------------------------

            int acceptable = 0;
            int their_user_number = 0;
            int their_channel_number = 0;

            for (int i = 0; i < userCounter; ++i) {
                if (strncmp(userNumber[i].authToken, auth_token_temp, 32) == 0) {
                    acceptable = 1;
                    their_user_number = i; //their number between every user
                    break;
                }
            }

            int done = 0;
            for (int i = 0; i < channelCounter; ++i) {
                for (int j = 0; j < channelNumber[i].people_inside; ++j) {
                    if (strcmp(channelNumber[i].member_name[j],userNumber[their_user_number].name) == 0) {
                        their_channel_number = i;
                        done = 1;
                        break;
                    }
                }
                if (done)
                    break;
            }

            if (acceptable == 0) {

                char messageForClientString[MAX] = "{\n"
                                               "        \"type\": \"Error\",\n"
                                               "        \"content\":      \"Unacceptable AuthToken.\"\n"
                                               "}";
                send(client_socket, messageForClientString, 10000, 0);
                printf("%s\n", messageForClientString);

            } else {

                // Checking if the user was joined in any channel ------------------------------------------------------

                if (userNumber[their_user_number].in_any_channel == 0) {
                    char messageForClientString[MAX] = "{\n"
                                                   "        \"type\": \"Error\",\n"
                                                   "        \"content\":      \"User isn't joined in any channels.\"\n"
                                                   "}";
                    send(client_socket, messageForClientString, 10000, 0);
                    printf("%s\n", messageForClientString);
                } else {

                    // Everything is ok now we remake the json ---------------------------------------------------------

                    char addressAndNameOfFile[MAX];
                    sprintf ( addressAndNameOfFile , "./Resources/Channels/%s.channel.json" , channelNumber[their_channel_number].channel_name );
                    FILE * filePointer = NULL;
                    filePointer = fopen (addressAndNameOfFile , "r+");
                    char contentString[MAX];
                    printf("sizeof(contentString) : %d\n", sizeof(contentString));
                    rewind(filePointer);
//                    fread(contentString, sizeof(char) , 10000, filePointer);
                    fscanf(filePointer, "%[^\0]", contentString);

                    printf("OLD SEND :\n%s\n", contentString);
                    puts("*********************************************************");
                    fseek(filePointer, -19 - strlen(channel_name), SEEK_END);
                    fprintf(filePointer, "}, {\n"
                                         "\t\t\t\"sender\":\t\"%s\",\n"
                                         "\t\t\t\"content\":\t\"%s\""
                                         "\n\t\t}],\n"
                                         "\t\"name\":\t\"%s\"\n"
                                         "}", userNumber[their_user_number].name, message, channel_name);
                    rewind(filePointer);
//                    fread(contentString, sizeof(char) , 10000, filePointer);
                    fscanf(filePointer, "%[^\0]", contentString);
                    printf("NEW SEND :\n%s\n", contentString);
                    puts("*********************************************************");
                    fclose ( filePointer );


                    // Sending a success message to client -------------------------------------------------------------

                    char messageForClientString[MAX] = "{\n"
                                                    "        \"type\": \"Successful\",\n"
                                                    "        \"content\":      \"\"\n"
                                                    "}";
                    send ( client_socket , messageForClientString , 10000 , 0 );
                    printf("%s\n", messageForClientString);
//                    puts("******************************************************************\n");

                }

            }
        }

        // --------------------------------------------- REFRESH -------------------------------------------------------

        else if (strncmp("refresh", buffer, 7) == 0){

            // Extraction ----------------------------------------------------------------------------------------------

            delchar(buffer, 8, 0);
            sscanf(buffer, "%s", auth_token_temp);

            // Checking if authToken is acceptable ---------------------------------------------------------------------

            int acceptable = 0;
            int their_user_number = 0;

            for (int i = 0; i < userCounter; ++i) {
                if (strncmp(userNumber[i].authToken, auth_token_temp, 32) == 0) {
                    acceptable = 1;
                    their_user_number = i; //their number between every user
                    break;
                }
            }

            if (acceptable == 0) {

                char messageForClientString[MAX] = "{\n"
                                               "        \"type\": \"Error\",\n"
                                               "        \"content\":      \"Unacceptable AuthToken.\"\n"
                                               "}";
                send(client_socket, messageForClientString, 10000, 0);
                printf("%s\n", messageForClientString);

            } else {

                // Checking if the user was joined in any channel ------------------------------------------------------


                if (userNumber[their_user_number].in_any_channel == 0) {
                    char messageForClientString[MAX] = "{\n"
                                                   "        \"type\": \"Error\",\n"
                                                   "        \"content\":      \"User isn't joined in any channels.\"\n"
                                                   "}";
                    send(client_socket, messageForClientString, 10000, 0);
                    printf("%s\n", messageForClientString);
                } else {

                    // Sending all messages to client ------------------------------------------------------------------

                    char addressAndNameOfFile[1000];
                    sprintf ( addressAndNameOfFile , "./Resources/Channels/%s.channel.json" , channel_name );
                    FILE * filePointer = NULL;
                    filePointer = fopen (addressAndNameOfFile , "r");
                    char contentString[10000];
//                    fread(contentString, sizeof(char) , 10000, filePointer);
                    fscanf(filePointer, "%[^\0]", contentString);
                    fclose(filePointer);

                    printf("OLDEST REFRESH : \n%s\n", contentString);
                    puts("*********************************************************");

//                    contentString [strlen(contentString) - strlen(channel_name) - 5] = '\0'; //idk why it happened
//
//                    printf("OLD REFRESH : \n%s\n", contentString);
//                    puts("*********************************************************");
//
                    strcpy(contentString, contentString + 15);
//
                    printf("NEW REFRESH : \n%s\n", contentString);
                    puts("*********************************************************");

                    // Sending a success message to client -------------------------------------------------------------

                    char messageForClientString[MAX];
                    sprintf(messageForClientString, "{\n"
                                                    "        \"type\": \"List\",\n"
                                                    "        \"content\":      %s", contentString);
                    send ( client_socket , messageForClientString , 10000 , 0 );
                    printf("message sent is \n%s\n", messageForClientString);

                }
            }
        }

        // ----------------------------------------- CHANNEL MEMBERS ---------------------------------------------------

        else if (strncmp("channel members", buffer, 15) == 0) {

            // Extraction ----------------------------------------------------------------------------------------------

            delchar(buffer, 16, 0);
            sscanf(buffer, "%s", auth_token_temp);

            // Checking if authToken is acceptable ---------------------------------------------------------------------

            int acceptable = 0;
            int their_user_number = 0;

            for (int i = 0; i < userCounter; ++i) {
                if (strncmp(userNumber[i].authToken, auth_token_temp, 32) == 0) {
                    acceptable = 1;
                    their_user_number = i; //their number between every user
                    break;
                }
            }

            if (acceptable == 0) {

                char messageForClientString[MAX] = "{\n"
                                               "        \"type\": \"Error\",\n"
                                               "        \"content\":      \"Unacceptable AuthToken.\"\n"
                                               "}";
                send(client_socket, messageForClientString, 10000, 0);
                printf("%s\n", messageForClientString);

            } else {

                // Checking if the user was joined in any channel ------------------------------------------------------


                if (userNumber[their_user_number].in_any_channel == 0) {
                    char messageForClientString[MAX] = "{\n"
                                                   "        \"type\": \"Error\",\n"
                                                   "        \"content\":      \"User isn't joined in any channels.\"\n"
                                                   "}";
                    send(client_socket, messageForClientString, 10000, 0);
                    printf("%s\n", messageForClientString);
                } else {

                    char channelString[MAX];

                    // What channel ------------------------------------------------------------------------------------

                    int their_channel_number = 0;

                    int done = 0;
                    for (int i = 0; i < channelCounter; ++i) {
                        for (int j = 0; j < channelNumber[i].people_inside; ++j) {
                            if (strcmp(channelNumber[i].member_name[j],userNumber[their_user_number].name) == 0) {
                                their_channel_number = i;
                                done = 1;
                                break;
                            }
                        }
                        if (done)
                            break;
                    }

                    sprintf(channelString, "{\n"
                                           "        \"type\": \"List\",\n"
                                           "        \"content\":      [\"%s\"", channelNumber[their_channel_number].member_name[0] );

                    char tempString[MAX];

                    // Putting the usernames in the json ---------------------------------------------------------------

                    for (int i = 1 ; i < channelNumber[their_channel_number].people_inside ; i++) {
                        sprintf(tempString, ", \"%s\"", channelNumber[their_channel_number].member_name[i]);
                        strcat(channelString, tempString);
                    }


                    strcat(channelString, "]\n}");

                    // Sending the message -----------------------------------------------------------------------------



                    send ( client_socket , channelString , 10000 , 0 );
                    printf("%s\n", channelString);

                }
            }
        }

        // ---------------------------------------------- LEAVE --------------------------------------------------------

        else if (strncmp("leave", buffer, 5) == 0){

            // Extraction ----------------------------------------------------------------------------------------------

            delchar(buffer, 6, 0);
            sscanf(buffer, "%s", auth_token_temp);

            // Checking if authToken is acceptable ---------------------------------------------------------------------

            int acceptable = 0;
            int their_user_number = 0;

            for (int i = 0; i < userCounter; ++i) {
                if (strncmp(userNumber[i].authToken, auth_token_temp, 32) == 0) {
                    acceptable = 1;
                    their_user_number = i; //their number between every user
                    break;
                }
            }

            if (acceptable == 0) {

                char messageForClientString[MAX] = "{\n"
                                               "        \"type\": \"Error\",\n"
                                               "        \"content\":      \"Unacceptable AuthToken.\"\n"
                                               "}";
                send(client_socket, messageForClientString, 10000, 0);
                printf("%s\n", messageForClientString);

            } else {

                // Checking if the user was joined in any channel ------------------------------------------------------


                if (userNumber[their_user_number].in_any_channel == 0) {

                    char messageForClientString[MAX] = "{\n"
                                                   "        \"type\": \"Error\",\n"
                                                   "        \"content\":      \"User isn't joined in any channels.\"\n"
                                                   "}";
                    send(client_socket, messageForClientString, 10000, 0);
                    printf("%s\n", messageForClientString);

                } else {

                    // Deleting the user from the respective channel ---------------------------------------------------

                    int their_channel_number = 0;

                    int done = 0;
                    for (int i = 0; i < channelCounter; ++i) {
                        for (int j = 0; j < channelNumber[i].people_inside; ++j) {
                            if (strcmp(channelNumber[i].member_name[j],userNumber[their_user_number].name) == 0) {
                                for (int k = j; k <= channelNumber[i].people_inside - 1; ++k) {
                                    if (k == channelNumber[i].people_inside - 1) {
                                        memset (channelNumber[i].member_name[j], 0, sizeof(channelNumber[i].member_name[j]));
                                        break;
                                    }
                                    strcpy(channelNumber[i].member_name[j], channelNumber[i].member_name[j + 1]);
                                }
                                channelNumber[i].people_inside--;
                                userNumber[their_user_number].in_any_channel = 0;
                                their_channel_number = i;
                                done = 1;
                                break;
                            }
                        }
                        if (done)
                            break;
                    }

                    // Everything is ok now we remake the json ---------------------------------------------------------

                    char addressAndNameOfFile[MAX];
                    sprintf ( addressAndNameOfFile , "./Resources/Channels/%s.channel.json" , channelNumber[their_channel_number].channel_name );
                    FILE * filePointer = NULL;
                    filePointer = fopen (addressAndNameOfFile , "r+");
                    char contentString[MAX];
                    printf("sizeof(contentString) : %d\n", sizeof(contentString));
                    rewind(filePointer);
//                    fread(contentString, sizeof(char) , 10000, filePointer);
                    fscanf(filePointer, "%[^\0]", contentString);
                    printf("OLD LEAVE :\n%s\n", contentString);
                    puts("*********************************************************");
                    fseek(filePointer, -19 - strlen(channel_name), SEEK_END);
                    fprintf(filePointer, "}, {\n"
                                         "\t\t\t\"sender\":\t\"server\",\n"
                                         "\t\t\t\"content\":\t\"%s left the channel.\""
                                         "\n\t\t}],\n"
                                         "\t\"name\":\t\"%s\"\n"
                                         "}", userNumber[their_user_number].name, channelNumber[their_channel_number].channel_name);
                    rewind(filePointer);
//                    fread(contentString, sizeof(char) , 10000, filePointer);
                    fscanf(filePointer, "%[^\0]", contentString);
                    printf("NEW LEAVE : \n%s\n", contentString);
                    puts("*********************************************************");
                    fclose ( filePointer );

                    // Sending a success message to client -------------------------------------------------------------

                    char messageForClientString[MAX] = "{\n"
                                                   "        \"type\": \"Successful\",\n"
                                                   "        \"content\":      \"\"\n"
                                                   "}";
                    send(client_socket, messageForClientString, 10000, 0);
                    printf("%s\n", messageForClientString);

                }
            }

        }

        // ---------------------------------------------- LOGOUT -------------------------------------------------------

        else if (strncmp("logout", buffer, 6) == 0){

            // Extracting Auth Token -----------------------------------------------------------------------------------

            delchar ( buffer , 7 , 0 );
            sscanf ( buffer , "%s" , auth_token_temp );

            // Checking if authToken is acceptable ---------------------------------------------------------------------

            int acceptable = 0;
            int their_user_number = 0;

            for (int i = 0; i < userCounter; ++i) {
                if (strncmp(userNumber[i].authToken, auth_token_temp, 32) == 0) {
                    acceptable = 1;
                    break;
                }
            }

            if (acceptable == 0) {

                char messageForClientString[MAX] = "{\n"
                                               "        \"type\": \"Error\",\n"
                                               "        \"content\":      \"Unacceptable AuthToken.\"\n"
                                               "}";
                send(client_socket, messageForClientString, 10000, 0);
                printf("%s\n", messageForClientString);

            } else {

                for (int i = 0; i < userCounter; ++i) {
                    if (strncmp(userNumber[i].authToken, auth_token_temp, 32) == 0) {
                        for (int j = i; j < userCounter - 1; ++j)
                            userNumber[j] = userNumber[j + 1];
                        userCounter--;
                        break;
                    }
                }

                char messageForClientString[MAX] = "{\n"
                                               "        \"type\": \"Successful\",\n"
                                               "        \"content\":      \"\"\n"
                                               "}";
                send(client_socket, messageForClientString, 10000, 0);
                printf("%s\n", messageForClientString);

            }

        }

        // If the message starts with "exit" then server exits and chat ends

        else if (strncmp("exit", buffer, 4) == 0)
        {
            printf("Server stopping...\n");
            return;
        }

        closesocket(client_socket);
    }
}

int main() {

    WORD wVersionRequested;
    WSADATA wsaData;
    int err;

    // Use the MAKEWORD(lowbyte, highbyte) macro declared in Windef.h
    wVersionRequested = MAKEWORD(2, 2);

    err = WSAStartup(wVersionRequested, &wsaData);
    if (err != 0) {
        // Tell the user that we could not find a usable Winsock DLL.
        printf("WSAStartup failed with error: %d\n", err);
        return 1;
    }

    // Create and verify socket
    server_socket = socket(AF_INET, SOCK_STREAM, 6);
    if (server_socket == INVALID_SOCKET)
        wprintf(L"socket function failed with error = %d\n", WSAGetLastError() );
    else
        //printf("Socket successfully created..\n");

        // Assign IP and port
        memset(&server, 0, sizeof(server));
    server.sin_family = AF_INET;
    server.sin_addr.s_addr = htonl(INADDR_ANY);
    server.sin_port = htons(PORT);

    if ((bind(server_socket, (SA *)&server, sizeof(server))) != 0)
    {
//        printf("Socket binding failed...\n");
        exit(0);
    }
    else
//        printf("Socket successfully bound..\n");

        // Now server is ready to listen and verify
    if ((listen(server_socket, 5)) != 0)
    {
//        printf("Listen failed...\n");
        exit(0);
    }
    else
//        printf("Server listening..\n");

        // Function for chatting between client and server
        chat();
    return 0;
}
