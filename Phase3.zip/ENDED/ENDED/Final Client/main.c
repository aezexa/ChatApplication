#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <winsock2.h>
#include <time.h>
// #include <unistd.h>

#define MAX 10000
#define PORT 12345
#define SA struct sockaddr

struct sockaddr_in servaddr, cli;
char auth_token[32];
char optional_clrscr[1] = "3";

void removeAll(char * str, const char toRemove)
{
    int i, j;
    int len = strlen(str);

    for(i=0; i<len; i++)
    {
        /*
         * If the character to remove is found then shift all characters to one
         * place left and decrement the length of string by 1.
         */
        if(str[i] == toRemove)
        {
            for(j=i; j<len; j++)
            {
                str[j] = str[j+1];
            }

            len--;

            // If a character is removed then make sure i doesn't increments
            i--;
        }
    }
}

void chatMenu(void)
{
    char buffer[MAX];
    char message[MAX];
    char type[MAX];
    char content[MAX];
    int n;
//    int time = 0;
    while(1){
        puts("1: Send Message"
             "\n2: Refresh"
             "\n3: Channel Members"
             "\n4: Leave Channel\n\n\n");
        int server_socket = socket(AF_INET, SOCK_STREAM, 0);
        if (server_socket == -1) {
            exit(0);
        }
//        else if (time++ == 0)
//            printf("Socket successfully created..\n");

        memset(&servaddr, 0, sizeof(servaddr));
        servaddr.sin_family = AF_INET;
        servaddr.sin_addr.s_addr = inet_addr("127.0.0.1");
        servaddr.sin_port = htons(PORT);

        memset(buffer, 0, sizeof(buffer));
        int number = 0;
        scanf("%d", &number);
        if (optional_clrscr[0] == '3')
            system("@cls||clear");
        getchar();

        if (number == 1){
            memset(message, 0, sizeof(message));
            printf("Enter your message: ");
            n = 0;

            while ((message[n++] = getchar()) != '\n')
                ;
            message[n-1] = '\0';
            snprintf(buffer,10000,"send %s, %s\n", message, auth_token);
            if (connect(server_socket, (SA*)&servaddr, sizeof(servaddr)) == 0)
                send(server_socket, buffer, sizeof(buffer), 0);
            memset(buffer, 0, sizeof(buffer));

            recv(server_socket, buffer, sizeof(buffer), 0);
            closesocket(server_socket);
        }

        if (number == 2){
            char huge_message[MAX];
            memset(huge_message, 0, sizeof(huge_message));
            sprintf(buffer,"refresh %s\n",auth_token);
            if (connect(server_socket, (SA*)&servaddr, sizeof(servaddr)) == 0)
                send(server_socket, buffer , sizeof(buffer), 0);
            else
                puts("MESSED UP");

            memset(buffer, 0, sizeof(buffer));

            recv(server_socket, huge_message, sizeof(huge_message), 0); // I DUNNO THIS PLACE, RETURN HERE //STRLEN DESTROYED IT ALL
            closesocket(server_socket);
//            printf("huge message is\n%s\n", huge_message);
            sscanf(huge_message, "%*s%*s%*s%*s%*s%[^\0]", content);
            content [ strlen(content) - 1 ] = '\0';
            strcpy (content, content+3);
//            printf("first content is\n%s\n", content);
            char sender[MAX];
            char sentMessage[MAX];
            int flag = 1;
            while (flag) {
                sscanf(content, "%*s%s%*s%[^\n]%*s%*s%[^\0]", sender, sentMessage, content);
                sender [ strlen(sender) - 2 ] = '\0';
                strcpy (sender, sender+1);
                sentMessage [ strlen(sentMessage) - 1 ] = '\0';
                strcpy (sentMessage, sentMessage+2);
                printf("%s : %s\n", sender, sentMessage);
//                printf("content is\n%s\n", content);
                flag = 0;
                for (int i = 0; i < strlen(content); i++) {
                    if (content[i] == ' ') {
                        flag = 1;
                        break;
                    }
                }
            }
            puts("");
        }
        if (number == 3){
            char huge_message[MAX];
            memset(huge_message, 0, sizeof(huge_message));
            sprintf(buffer,"channel members %s\n",auth_token);
            if (connect(server_socket, (SA*)&servaddr, sizeof(servaddr)) == 0)
                send(server_socket, buffer , sizeof(buffer), 0);
            else
                puts("MESSED UP");

            memset(buffer, 0, sizeof(buffer));

            recv(server_socket, huge_message, sizeof(huge_message), 0); // I DUNNO THIS PLACE, RETURN HERE
            closesocket(server_socket);
            sscanf(huge_message, "%*s%*s%*s%*s%[^\0]", content);
            content [ strlen ( content ) - 1] = '\0';
            strcpy (content, content+2);
//            printf("content is %s\n", content);
            char guy[MAX];
            int i = 1;
            int flag = 1;
            while (flag) {
                sscanf(content, "%s%[^\0]", guy, content);
                guy [ strlen (guy) - 2 ] = '\0';
                strcpy (guy, guy+1);
                if (content[0] == '\n')
                    flag = 0;
                if (i == 1) {
                    printf("%d. %s\n", i, guy+1);
                }
                else {
                    printf("%d. %s\n", i, guy);
                }
                i++;
            }
            puts("");
        }
        if (number == 4){
            sprintf(buffer, "leave %s\n", auth_token);
            puts("Aaah Yiu Shou?\n...\n...\n(Are You Sure...?)\nYou HAVE TO answer with y or n...");
            while(1){
                char stupid_answer[1];
                scanf("%s", stupid_answer);
                if (optional_clrscr[0] == '3')
                    system("@cls||clear");
                if (stupid_answer[0] == 'y'){
                    if (connect(server_socket, (SA*)&servaddr, sizeof(servaddr)) == 0)
                        send(server_socket, buffer , sizeof(buffer), 0);
                    else
                        puts("MESSED UP");

                    memset(buffer, 0, sizeof(buffer));

                    recv(server_socket, buffer, sizeof(buffer), 0);
                    closesocket(server_socket);
                    if (optional_clrscr[0] == '3')
                        system("@cls||clear");
                    return;
                }
                else if (stupid_answer[0] == 'n'){
                    puts("Ok...\nhaha...\n(I'm dead inside, help me)");
                    break;
                }
                else
                    puts("Why did you type that? What did I ever do to you? ;-;");
            }
        }
    }
}

void mainMenu(void)
{
    char type[MAX];
    char content[MAX];
    char buffer[MAX];
//    int time = 0;
    while(1){
        puts("1: Create Channel"
             "\n2: Join Channel"
             "\n3: Logout\n\n\n");
        int server_socket = socket(AF_INET, SOCK_STREAM, 0);
        if (server_socket == -1) {
            exit(0);
        }
//        else if (time++ == 0)
//            printf("Socket successfully created..\n");
        memset(&servaddr, 0, sizeof(servaddr));
        servaddr.sin_family = AF_INET;
        servaddr.sin_addr.s_addr = inet_addr("127.0.0.1");
        servaddr.sin_port = htons(PORT);

        memset(buffer, 0, sizeof(buffer));
        int number;
        scanf("%d", &number);
        if (optional_clrscr[0] == '3')
            system("@cls||clear");
        if (number == 1){
            char channel_name[MAX];
            if (optional_clrscr[0] == '3')
                system("@cls||clear");
            puts("Enter Channel Name please (please just do it)\n");
            scanf("%s", channel_name);
            if (optional_clrscr[0] == '3')
                system("@cls||clear");
            sprintf(buffer,"create channel %s, %s\n",channel_name,auth_token);
            if (connect(server_socket, (SA*)&servaddr, sizeof(servaddr)) == 0)
                send(server_socket, buffer , sizeof(buffer), 0);
            else
                puts("MESSED UP");

            memset(buffer, 0, sizeof(buffer));

            recv(server_socket, buffer, sizeof(buffer), 0);
            closesocket(server_socket);
            sscanf(buffer, "%*s%*s%s%*s%s%*s", type, content);
            type [ strlen(type) - 2 ] = '\0';
            strcpy (type, type+1);
            content [ strlen(content) - 1 ] = '\0';
            strcpy (content, content+1);
            if (strcmp(type,"Successful") == 0){
                puts("You did it! You created that channel! You are like a leader now! :D");
                chatMenu();
            }
            else
                puts("Unfortunately, we have faced some difficulties and therefore cannot make this channel :("
                     "\n(I'm kidding, The truth is that this channel had been made previously.)");
        }
        if (number == 2){
            char channel_name[MAX];
            if (optional_clrscr[0] == '3')
                system("@cls||clear");
            puts("Enter Channel Name\n");
            scanf("%s", channel_name);
            if (optional_clrscr[0] == '3')
                system("@cls||clear");
            sprintf(buffer,"join channel %s, %s\n",channel_name,auth_token);

            if (connect(server_socket, (SA*)&servaddr, sizeof(servaddr)) == 0)
                send(server_socket, buffer , sizeof(buffer), 0);
            else
                puts("MESSED UP");

            memset(buffer, 0, sizeof(buffer));

            recv(server_socket, buffer, sizeof(buffer), 0);
            closesocket(server_socket);
            sscanf(buffer, "%*s%*s%s%*s%s%*s", type, content);
            type [ strlen(type) - 2 ] = '\0';
            strcpy (type, type+1);
            content [ strlen(content) - 1 ] = '\0';
            strcpy (content, content+1);
            if (strcmp(type,"Successful") == 0){
                puts("Yaaay, you joined a channel! I hope you have a lot of fun with your new friends!");
                chatMenu();
            }
            else if (strcmp(content,"Channel not found.") == 0){
                if (optional_clrscr[0] == '3')
                    system("@cls||clear");
                puts("You might've thought there was a channel with this name...\n"
                     "But...................\n"
                     "...\n"
                     "What\n"
                     "...");
            }
        }
        if (number == 3){
            sprintf(buffer,"logout %s\n", auth_token);
            if (connect(server_socket, (SA*)&servaddr, sizeof(servaddr)) == 0)
                send(server_socket, buffer , sizeof(buffer), 0);
            else
                puts("MESSED UP");

            memset(buffer, 0, sizeof(buffer));

            recv(server_socket, buffer, sizeof(buffer), 0);
            closesocket(server_socket);
            if (optional_clrscr[0] == '3')
                system("@cls||clear");
            puts("Successfully did what you wanted to do."
                 "\n(If you didn't get it, I meant logging off...)"
                 "\nOf course you got what I meant, it was just in case...");
            return;
        }
    }
}

void userMenu(void)
{
//    int time = 0;
    char buffer[MAX];
    char username[MAX];
    char password[MAX];
    char recieved_content[MAX];
    char type[MAX];
    char content[MAX];

    while(1){
        int server_socket = socket(AF_INET, SOCK_STREAM, 0);
        if (server_socket == -1) {
            exit(0);
        }
//        else if (time++ == 0)
//            printf("Socket successfully created..\n");

        memset(&servaddr, 0, sizeof(servaddr));
        servaddr.sin_family = AF_INET;
        servaddr.sin_addr.s_addr = inet_addr("127.0.0.1");
        servaddr.sin_port = htons(PORT);

        puts("Account Menu: "
             "\n1: Register... (Making new accounts is always fun, anyway you look at it!)"
             "\n2: Login... I hope you remember your password :D"
             "\n3: Clear screen each time something happens! (Default)"
             "\n4: Exactly the opposite of the upper item."
             "\n5: Exit this app ;-; (Of course you wouldn't, it's just a useless button...)\n\n\n");
        memset(buffer, 0, sizeof(buffer));
        int number = 0;
        scanf("%d", &number);
        if (optional_clrscr[0] == '3')
            system("@cls||clear");
        if (number == 1){
            puts("Enter Your Beautifully Thought Username\n");
            scanf("%s", username);
            if (optional_clrscr[0] == '3')
                system("@cls||clear");
            puts("Enter Your Delicate Password... Go on. I won't bite...\n");
            scanf("%s", password);
            if (optional_clrscr[0] == '3')
                system("@cls||clear");
            memset(buffer, 0, sizeof(buffer));
            sprintf(buffer,"register %s, %s\n", username, password);
            if (connect(server_socket, (SA*)&servaddr, sizeof(servaddr)) == 0)
                send(server_socket, buffer , sizeof(buffer), 0);
            else
                puts("MESSED UP");

            memset(buffer, 0, sizeof(buffer));

            recv(server_socket, buffer, 10000, 0);
            // Extracting type and content
            sscanf(buffer, "%*s%*s%s%*s%s%*s", type, content);
            type [ strlen(type) - 2 ] = '\0';
            strcpy (type, type+1);
            content [ strlen(content) - 1 ] = '\0';
            strcpy (content, content+1);
//            printf("type : %s\ncontent : %s\n", type, content);
            // ---------------------------
            if (strcmp(type,"Successful") == 0){
                if (optional_clrscr[0] == '3')
                    system("@cls||clear");
                puts("Successfully Registered! I hope your life becomes divided into \n"
                     "two parts, one before you met this app, and one after you did :)\n"
                     "Now try logging in!\n\n\n");
            }
            else{
                if (optional_clrscr[0] == '3')
                    system("@cls||clear");
                puts("It seems that there's an account with this username, but you messed up in the password part!\n"
                     "Please try your best to find your correct password, and try again in the login part.\n"
                     "I believe in you!\nAlso, if you're a thief, go away :|\n\n\n");
            }
//            free(type);
//            free(content);
            closesocket(server_socket);
        }
        else if (number == 2){
            puts("Enter The Username You Thought Of Somehow...\n");
            scanf("%s", username);
            if (optional_clrscr[0] == '3')
                system("@cls||clear");
            puts("Enter Your Strange Password\n");
            scanf("%s", password);
            if (optional_clrscr[0] == '3')
                system("@cls||clear");
            memset(buffer, 0, sizeof(buffer));
            sprintf(buffer,"login %s, %s\n", username, password);
            if (connect(server_socket, (SA*)&servaddr, sizeof(servaddr)) == 0)
                send(server_socket, buffer , sizeof(buffer), 0);
            else
                puts("MESSED UP");

            memset(buffer, 0, sizeof(buffer));

            recv(server_socket, buffer, sizeof(buffer), 0);
            closesocket(server_socket);
            sscanf(buffer, "%*s%*s%s%*s%[^\0]", type, content);
            type [ strlen(type) - 2 ] = '\0';
            strcpy (type, type+1);
            content [ strlen(content) - 3 ] = '\0';
            strcpy (content, content+7);
            printf("content 3 is %s\n", content);
            memset(recieved_content, 0, sizeof(recieved_content));
            sprintf(recieved_content,"The user %s is already logged in.", username);
            if (strcmp(type,"AuthToken") == 0){
                strcpy(auth_token,content); //or char* auth_tokenPtr = ...
                if (optional_clrscr[0] == '3')
                    system("@cls||clear");
                puts("WOOOWW!!! Congratulations! You logged in! That's a "
                     "huge step towards success!\nYou are AWESOME!!!\n\n\n");
                mainMenu();
            }
            else if (strcmp(content,recieved_content) == 0){
                if (optional_clrscr[0] == '3')
                    system("@cls||clear");
                puts("You are logged in, there's no need to try things twice. Life's short.\n"
                     "Go experience new things! :D\n"
                     "(Also, if you wanna logout from that account, since you don't have the authentication token,"
                     " we can't do anything for you. You gotta go to Resources, then Users, and delete your account."
                     " And don't tell anyone...)\n\n\n");
            }

            else if (strcmp(content,"Wrong password.") == 0){
                if (optional_clrscr[0] == '3')
                    system("@cls||clear");
                puts("Wrong pass mate!\nMaybe I can log you in, just try writing the correct password.\n"
                     "I won't log you in unless you show me you're not a thief :D\n\n\n");
            }
            else if (strcmp(content,"Username is not valid.") == 0){
                if (optional_clrscr[0] == '3')
                    system("@cls||clear");
                puts("This username doesn't even exist bro :D\n\n\n");
            }
        }
        else if (number == 3)
            optional_clrscr[0] = '3';
        else if (number == 4)
            optional_clrscr[0] = '4';
        else if (number == 5){
            puts("Are you sure you wanna leave me? ;-; (y or n)\nDon't type anything else... (pretty please)");
            while(1){
                char stupid_answer[1];
                scanf("%s", stupid_answer);
                if (optional_clrscr[0] == '3')
                    system("@cls||clear");
                if (stupid_answer[0] == 'y'){
                    puts("Bye.... ;-;");
                    Sleep(2000);
                    exit(0);
                }
                else if (stupid_answer[0] == 'n'){
                    puts("I knew you weren't coldhearted ^^");
                    break;
                }
                else
                    puts("Haha what are you typing? :D");
            }
        }
        else{
            if (optional_clrscr[0] == '3')
                system("@cls||clear");
            puts("You typed in something absurd");
        }
    }
}






int main() {
//	struct sockaddr_in servaddr, cli;

    WORD wVersionRequested;
    WSADATA wsaData;
    int err;


    // Use the MAKEWORD(lowbyte, highbyte) macro declared in Windef.h
    wVersionRequested = MAKEWORD(2, 2);

    err = WSAStartup(wVersionRequested, &wsaData);
    if (err != 0) {
        // Tell the user that we could not find a usable Winsock DLL.
        printf("WSAStartup failed with error: %d\n", err);
        return 1;
    }
    system("color E4");
    userMenu();

    return 0;
}
