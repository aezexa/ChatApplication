#ifndef MAIN_MENU_GUARD_HEADER
#define MAIN_MENU_GUARD_HEADER

#include "main.h"

void mainMenu(void);

#endif // MAIN_MENU_GUARD_HEADER