#ifndef CHAT_MENU_GUARD_HEADER
#define CHAT_MENU_GUARD_HEADER

#include "main.h"

void chatMenu(void);

#endif // CHAT_MENU_GUARD_HEADER