#include "mainMenu.h"

void mainMenu(void)
{
    char buffer[MAX];
//    int time = 0;
    while(1){
        puts("1: Create Channel"
            "\n2: Join Channel"
            "\n3: Logout\n\n\n");
        int server_socket = socket(AF_INET, SOCK_STREAM, 0);
        if (server_socket == -1) {
            exit(0);
        }
//        else if (time++ == 0)
//            printf("Socket successfully created..\n");
        memset(&servaddr, 0, sizeof(servaddr));
        servaddr.sin_family = AF_INET;
        servaddr.sin_addr.s_addr = inet_addr("127.0.0.1");
        servaddr.sin_port = htons(PORT);

        memset(buffer, 0, sizeof(buffer));
        int number;
        scanf("%d", &number);
        if (optional_clrscr[0] == '3')
            system("@cls||clear");
        if (number == 1){
            char channel_name[MAX];
            if (optional_clrscr[0] == '3')
                system("@cls||clear");
            puts("Enter Channel Name please (please just do it)\n");
            scanf("%s", channel_name);
            if (optional_clrscr[0] == '3')
                system("@cls||clear");
            sprintf(buffer,"create channel %s, %s\n",channel_name,auth_token);
            if (connect(server_socket, (SA*)&servaddr, sizeof(servaddr)) == 0)
                send(server_socket, buffer , sizeof(buffer), 0);
            else
                puts("MESSED UP");

            memset(buffer, 0, sizeof(buffer));

            recv(server_socket, buffer, sizeof(buffer), 0);
            closesocket(server_socket);
            cJSON* recieved_string = cJSON_Parse(buffer);
            if (strcmp(cJSON_GetObjectItemCaseSensitive(recieved_string,"type")->valuestring,"Successful") == 0){
                puts("You did it! You created that channel! You are like a leader now! :D");
                chatMenu();
            }
            else
                puts("Unfortunately, we have faced some difficulties and therefore cannot make this channel :("
                     "\n(I'm kidding, The truth is that this channel had been made previously.)");
        }
        if (number == 2){
            char channel_name[MAX];
            if (optional_clrscr[0] == '3')
                system("@cls||clear");
            puts("Enter Channel Name\n");
            scanf("%s", channel_name);
            if (optional_clrscr[0] == '3')
                system("@cls||clear");
            sprintf(buffer,"join channel %s, %s\n",channel_name,auth_token);

            if (connect(server_socket, (SA*)&servaddr, sizeof(servaddr)) == 0)
                send(server_socket, buffer , sizeof(buffer), 0);
            else
                puts("MESSED UP");

            memset(buffer, 0, sizeof(buffer));

            recv(server_socket, buffer, sizeof(buffer), 0);
            closesocket(server_socket);
            cJSON* recieved_string = cJSON_Parse(buffer);
            if (strcmp(cJSON_GetObjectItemCaseSensitive(recieved_string,"type")->valuestring,"Successful") == 0){
                puts("Yaaay, you joined a channel! I hope you have a lot of fun with your new friends!");
                chatMenu();
            }
            else if (strcmp(cJSON_GetObjectItemCaseSensitive(recieved_string,"content")->valuestring,"Channel not found.") == 0){
                if (optional_clrscr[0] == '3')
                    system("@cls||clear");
                puts("You might've thought there was a channel with this name...\n"
                     "But...................\n"
                     "...\n"
                     "What\n"
                     "...");
            }
        }
        if (number == 3){
            sprintf(buffer,"logout %s\n", auth_token);
            if (connect(server_socket, (SA*)&servaddr, sizeof(servaddr)) == 0)
                send(server_socket, buffer , sizeof(buffer), 0);
            else
                puts("MESSED UP");

            memset(buffer, 0, sizeof(buffer));

            recv(server_socket, buffer, sizeof(buffer), 0);
            closesocket(server_socket);
            if (optional_clrscr[0] == '3')
                system("@cls||clear");
            puts("Successfully did what you wanted to do."
                 "\n(If you didn't get it, I meant logging off...)"
                 "\nOf course you got what I meant, it was just in case...");
            return;
        }
    }
}
