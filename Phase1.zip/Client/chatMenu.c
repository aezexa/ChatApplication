#include "chatMenu.h"

void chatMenu(void)
{
    char buffer[MAX];
    char message[MAX];
    int n;
//    int time = 0;
    while(1){
        puts("1: Send Message"
            "\n2: Refresh"
            "\n3: Channel Members"
            "\n4: Leave Channel\n\n\n");
        int server_socket = socket(AF_INET, SOCK_STREAM, 0);
        if (server_socket == -1) {
            exit(0);
        }
//        else if (time++ == 0)
//            printf("Socket successfully created..\n");

        memset(&servaddr, 0, sizeof(servaddr));
        servaddr.sin_family = AF_INET;
        servaddr.sin_addr.s_addr = inet_addr("127.0.0.1");
        servaddr.sin_port = htons(PORT);

        memset(buffer, 0, sizeof(buffer));
        int number;
        scanf("%d", &number);
        if (optional_clrscr[0] == '3')
            system("@cls||clear");
        getchar();

        if (number == 1){
            memset(message, 0, sizeof(message));
            printf("Enter your message: ");
            n = 0;

            while ((message[n++] = getchar()) != '\n')
                ;
            message[n-1] = '\0';
            snprintf(buffer,10000,"send %s, %s\n", message, auth_token);
            if (connect(server_socket, (SA*)&servaddr, sizeof(servaddr)) == 0)
                send(server_socket, buffer, sizeof(buffer), 0);
            memset(buffer, 0, sizeof(buffer));

            recv(server_socket, buffer, sizeof(buffer), 0);
            closesocket(server_socket);
            }

        if (number == 2){
            char huge_message[MAX];
            memset(huge_message, 0, sizeof(huge_message));
            sprintf(buffer,"refresh %s\n",auth_token);
            if (connect(server_socket, (SA*)&servaddr, sizeof(servaddr)) == 0)
                send(server_socket, buffer , sizeof(buffer), 0);
            else
                puts("MESSED UP");

            memset(buffer, 0, sizeof(buffer));

            recv(server_socket, huge_message, sizeof(huge_message), 0); // I DUNNO THIS PLACE, RETURN HERE
            closesocket(server_socket);
            cJSON* content_message = cJSON_Parse(huge_message);
            cJSON *huge_content = cJSON_GetObjectItem(content_message, "content");
            for (int i = 0; i < cJSON_GetArraySize(huge_content); i++){
                cJSON* subitem = cJSON_GetArrayItem(huge_content, i);
                printf("%s : %s\n", cJSON_GetObjectItem(subitem, "sender")->valuestring, cJSON_GetObjectItem(subitem, "content")->valuestring);
            }
            puts("");
//            printf("%s\n", cJSON_GetObjectItemCaseSensitive(content_message,"content")->valuestring);
        }
        if (number == 3){
            char huge_message[MAX];
            memset(huge_message, 0, sizeof(huge_message));
            sprintf(buffer,"channel members %s\n",auth_token);
            if (connect(server_socket, (SA*)&servaddr, sizeof(servaddr)) == 0)
                send(server_socket, buffer , sizeof(buffer), 0);
            else
                puts("MESSED UP");

            memset(buffer, 0, sizeof(buffer));

            recv(server_socket, huge_message, sizeof(huge_message), 0); // I DUNNO THIS PLACE, RETURN HERE
            closesocket(server_socket);
            cJSON* content_message = cJSON_Parse(huge_message);
            cJSON *huge_content = cJSON_GetObjectItem(content_message, "content");
            for (int i = 0; i < cJSON_GetArraySize(huge_content); i++){
//                content = cJSON_GetObjectItem(subitem, "content")->valuestring;
                printf("%d. %s\n", i+1, cJSON_GetArrayItem(huge_content, i)->valuestring);
            }
            puts("");
//            cJSON* content_message = cJSON_Parse(huge_message);
//            printf("%s\n", cJSON_GetObjectItemCaseSensitive(content_message,"content")->valuestring);
        }
        if (number == 4){
            sprintf(buffer, "leave %s\n", auth_token);
            puts("Aaah Yiu Shou?\n...\n...\n(Are You Sure...?)\nYou HAVE TO answer with y or n...");
            while(1){
                char stupid_answer[1];
                scanf("%s", stupid_answer);
                if (optional_clrscr[0] == '3')
                    system("@cls||clear");
                if (stupid_answer[0] == 'y'){
                    if (connect(server_socket, (SA*)&servaddr, sizeof(servaddr)) == 0)
                        send(server_socket, buffer , sizeof(buffer), 0);
                    else
                        puts("MESSED UP");

                    memset(buffer, 0, sizeof(buffer));

                    recv(server_socket, buffer, sizeof(buffer), 0);
                    closesocket(server_socket);
                    if (optional_clrscr[0] == '3')
                        system("@cls||clear");
                    return;
                }
                else if (stupid_answer[0] == 'n'){
                    puts("Ok...\nhaha...\n(I'm dead inside, help me)");
                    break;
                }
                else
                    puts("Why did you type that? What did I ever do to you? ;-;");
            }
        }
    }
}
