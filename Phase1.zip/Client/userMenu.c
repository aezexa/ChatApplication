#include "userMenu.h"

void userMenu(void)
{
    char number[1];
//    int time = 0;
    char buffer[MAX];
	char username[MAX];
	char password[MAX];
	char recieved_content[MAX];

    while(1){
        int server_socket = socket(AF_INET, SOCK_STREAM, 0);
        if (server_socket == -1) {
            exit(0);
        }
//        else if (time++ == 0)
//            printf("Socket successfully created..\n");

        memset(&servaddr, 0, sizeof(servaddr));
        servaddr.sin_family = AF_INET;
        servaddr.sin_addr.s_addr = inet_addr("127.0.0.1");
        servaddr.sin_port = htons(PORT);

        puts("Account Menu: "
        "\n1: Register... (Making new accounts is always fun, anyway you look at it!)"
        "\n2: Login... I hope you remember your password :D"
        "\n3: Clear screen each time something happens! (Default)"
        "\n4: Exactly the opposite of the upper item."
        "\n5: Exit this app ;-; (Of course you wouldn't, it's just a useless button...)\n\n\n");
        memset(buffer, 0, sizeof(buffer));
        scanf("%s", number);
        if (optional_clrscr[0] == '3')
            system("@cls||clear");
        if (number[0] == '1'){
            puts("Enter Your Beautifully Thought Username\n");
            scanf("%s", username);
            if (optional_clrscr[0] == '3')
                system("@cls||clear");
            puts("Enter Your Delicate Password... Go on. I won't bite...\n");
            scanf("%s", password);
            if (optional_clrscr[0] == '3')
                system("@cls||clear");
            memset(buffer, 0, sizeof(buffer));
            sprintf(buffer,"register %s, %s\n", username, password);
            if (connect(server_socket, (SA*)&servaddr, sizeof(servaddr)) == 0)
                send(server_socket, buffer , sizeof(buffer), 0);
            else
                puts("MESSED UP");

            memset(buffer, 0, sizeof(buffer));

            recv(server_socket, buffer, sizeof(buffer), 0);
            cJSON* recieved_string = cJSON_Parse(buffer);
            if (strcmp(cJSON_GetObjectItemCaseSensitive(recieved_string,"type")->valuestring,"Successful") == 0){
                if (optional_clrscr[0] == '3')
                    system("@cls||clear");
                puts("Successfully Registered! I hope your life becomes divided into \n"
                     "two parts, one before you met this app, and one after you did :)\n"
                     "Now try logging in!\n\n\n");
            }
            else{
                if (optional_clrscr[0] == '3')
                    system("@cls||clear");
                puts("It seems that there's an account with this username, but you messed up in the password part!\n"
                     "Please try your best to find your correct password, and try again in the login part.\n"
                     "I believe in you!\nAlso, if you're a thief, go away :|\n\n\n");
            }

            closesocket(server_socket);
        }
            else if (number[0] == '2'){
                puts("Enter The Username You Thought Of Somehow...\n");
                scanf("%s", username);
                if (optional_clrscr[0] == '3')
                    system("@cls||clear");
                puts("Enter Your Strange Password\n");
                scanf("%s", password);
                if (optional_clrscr[0] == '3')
                    system("@cls||clear");
                memset(buffer, 0, sizeof(buffer));
                sprintf(buffer,"login %s, %s\n", username, password);
                if (connect(server_socket, (SA*)&servaddr, sizeof(servaddr)) == 0)
                    send(server_socket, buffer , sizeof(buffer), 0);
                else
                    puts("MESSED UP");

                memset(buffer, 0, sizeof(buffer));

                recv(server_socket, buffer, sizeof(buffer), 0);
                closesocket(server_socket);
                cJSON* recieved_string = cJSON_Parse(buffer);
                memset(recieved_content, 0, sizeof(recieved_content));
                sprintf(recieved_content,"The user %s is already logged in.", username);
                if (strcmp(cJSON_GetObjectItemCaseSensitive(recieved_string,"type")->valuestring,"AuthToken") == 0){
                    strcpy(auth_token,cJSON_GetObjectItemCaseSensitive(recieved_string,"content")->valuestring); //or char* auth_tokenPtr = ...
                    if (optional_clrscr[0] == '3')
                        system("@cls||clear");
                    puts("WOOOWW!!! Congratulations! You logged in! That's a "
                         "huge step towards success!\nYou are AWESOME!!!\n\n\n");
                    mainMenu();
                }
                else if (strcmp(cJSON_GetObjectItemCaseSensitive(recieved_string,"content")->valuestring,recieved_content) == 0){
                    if (optional_clrscr[0] == '3')
                        system("@cls||clear");
                    puts("You are logged in, there's no need to try things twice. Life's short.\n"
                         "Go experience new things! :D\n"
                         "(Also, if you wanna logout from that account, since you don't have the authentication token,"
                         " we can't do anything for you. You gotta go to Resources, then Users, and delete your account."
                         " And don't tell anyone...)\n\n\n");
                    }

                else if (strcmp(cJSON_GetObjectItemCaseSensitive(recieved_string,"content")->valuestring,"Wrong password.") == 0){
                    if (optional_clrscr[0] == '3')
                        system("@cls||clear");
                    puts("Wrong pass mate!\nMaybe I can log you in, just try writing the correct password.\n"
                         "I won't log you in unless you show me you're not a thief :D\n\n\n");
                }
            }
            else if (number[0] == '3')
                optional_clrscr[0] = '3';
            else if (number[0] == '4')
                optional_clrscr[0] = '4';
            else if (number[0] == '5'){
                puts("Are you sure you wanna leave me? ;-; (y or n)\nDon't type anything else... (pretty please)");
                while(1){
                    char stupid_answer[1];
                    scanf("%s", stupid_answer);
                    if (optional_clrscr[0] == '3')
                        system("@cls||clear");
                    if (stupid_answer[0] == 'y'){
                        puts("Bye.... ;-;");
                        Sleep(2000);
                        exit(0);
                    }
                    else if (stupid_answer[0] == 'n'){
                        puts("I knew you weren't coldhearted ^^");
                        break;
                    }
                    else
                        puts("Haha what are you typing? :D");
                }
            }
            else{
                if (optional_clrscr[0] == '3')
                    system("@cls||clear");
                puts("You typed in something absurd");
            }
    }
}
