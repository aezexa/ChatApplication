#ifndef MAIN_GUARD_HEADER
#define MAIN_GUARD_HEADER

#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <winsock2.h>
#include <time.h>
// #include <unistd.h>

#include "cJSON.h"

#define MAX 10000
#define PORT 12345
#define SA struct sockaddr

extern struct sockaddr_in servaddr, cli;
extern char auth_token[32];
extern char optional_clrscr[1];

#endif // MAIN_GUARD_HEADER